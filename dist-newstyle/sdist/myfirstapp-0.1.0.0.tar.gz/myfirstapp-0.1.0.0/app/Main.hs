module Main where

import UI.Routes (routes)
import UI.Types (initStore)

main :: IO ()
main = do
  routes initStore