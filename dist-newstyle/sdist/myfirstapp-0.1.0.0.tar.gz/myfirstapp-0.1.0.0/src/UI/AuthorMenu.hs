module UI.AuthorMenu (
  authorMenu
) where
  import Data.Char (isDigit)
  import Models.Author (createAuthorList, printAuthor)
  import Modules.File (customReadFile)
  import Modules.Search (findAuthor, findSubStrIdx)
  import UI.Types (Store, createStore)
  import UI.Tools (clearScreen, printError, printHeader, printPagination, printNoticeList)

  _PAGINATE_PER :: Int
  _PAGINATE_PER = 10

  authorMenu :: Int -> String -> IO (Store)
  authorMenu pageNumber searchValue = do
    printHeader "Меню авторов"

    contents <- customReadFile "db/author_db.txt"
    let linesOfFile = lines contents
    let authorList =
          case (length searchValue) of
            0 -> createAuthorList linesOfFile []
            _ -> findAuthor searchValue (createAuthorList linesOfFile [])

    putStrLn ""
    putStrLn (replicate 100 '-')
    mapM_ printAuthor (take _PAGINATE_PER (drop ((pageNumber - 1) * _PAGINATE_PER) authorList))
    putStrLn ""

    printNoticeList [
      "Чтобы выйти в главное меню, напишите: 'Exit'",
      "Чтобы очистить поиск, напишите 'Clear'",
      "Чтобы начать поиск книг по авторам, напишите 'Search'",
      "Чтобы начать пользоваться поиском, введите любое значение"
      ]

    let pages = ceiling (fromIntegral (length authorList) / fromIntegral _PAGINATE_PER)
    printPagination pageNumber pages

    input <- getLine
    if (all isDigit input)
      then do
        let index = read input :: Int
        digitOperations index pages pageNumber
      else do
        stringOperations input pageNumber

  digitOperations :: Int -> Int -> Int -> IO (Store)
  digitOperations index pages pageNumber
    | (index <= pages) = do
      clearScreen
      authorMenu index ""
    | otherwise = do
      clearScreen
      printError "Выход за пределы пагинации"
      authorMenu pageNumber ""

  stringOperations :: String -> Int -> IO (Store)
  stringOperations inputValue pageNumber
    | (findSubStrIdx inputValue "Exit" 0 /= Nothing) = do
      return (createStore "StartMenu" "")
    | (findSubStrIdx inputValue "Clear" 0 /= Nothing) = do
      clearScreen
      authorMenu pageNumber ""
    | (findSubStrIdx inputValue "Search" 0 /= Nothing) = do
      clearScreen
      return (createStore "BookMenu" inputValue)
    | otherwise = do
      clearScreen
      authorMenu pageNumber inputValue
