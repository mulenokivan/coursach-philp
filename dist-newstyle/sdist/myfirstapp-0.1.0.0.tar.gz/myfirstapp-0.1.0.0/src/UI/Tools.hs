module UI.Tools (
  clearScreen,
  printOptions,
  printError,
  printHeader,
  printPagination,
  printNotice,
  printNoticeList
) where
  import qualified System.Console.ANSI as ANSI

  clearScreen :: IO ()
  clearScreen = do
    ANSI.clearScreen
    ANSI.setCursorPosition 0 0

  printOptions :: [(String, String, Bool)] -> IO ()
  printOptions options =
    mapM_ putStrLn optionsString

    where
      optionsString = map (\(s, _, _) -> s) options

  printError :: String -> IO ()
  printError errorText = do
    ANSI.setSGR [ANSI.SetColor ANSI.Foreground ANSI.Vivid ANSI.White]
    ANSI.setSGR [ANSI.SetColor ANSI.Background ANSI.Vivid ANSI.Red]
    putStrLn (replicate 100 '*')
    putStrLn "Ошибка:"
    putStrLn errorText
    putStrLn (replicate 100 '*')
    ANSI.setSGR [ANSI.Reset]

  printHeader :: String -> IO ()
  printHeader header = do
    putStrLn (replicate 100 '*')
    putStrLn ""
    ANSI.setSGR [ANSI.SetColor ANSI.Foreground ANSI.Vivid ANSI.Yellow]
    putStrLn header
    ANSI.setSGR [ANSI.Reset]
    putStrLn ""
    putStrLn (replicate 100 '*')

  printPagination :: Int -> Int -> IO ()
  printPagination pageNumber pages = do
    putStrLn "Страницы"
    putStrLn ("[" ++ (show pageNumber) ++ "/" ++ (show pages) ++ "]")

  printNotice :: String -> IO ()
  printNotice noticeText = do
    putStrLn (replicate 100 '*')
    putStrLn (replicate 100 '*')
    ANSI.setSGR [ANSI.SetColor ANSI.Foreground ANSI.Vivid ANSI.Cyan]
    putStrLn "Заметка:"
    putStrLn noticeText
    ANSI.setSGR [ANSI.Reset]
    putStrLn (replicate 100 '*')

  printNoticeList :: [String] -> IO ()
  printNoticeList noticeList = do
    putStrLn (replicate 100 '*')
    putStrLn (replicate 100 '*')
    ANSI.setSGR [ANSI.SetColor ANSI.Foreground ANSI.Vivid ANSI.Cyan]
    putStrLn "Заметка:"
    mapM_ putStrLn noticeList
    ANSI.setSGR [ANSI.Reset]
    putStrLn (replicate 100 '*')