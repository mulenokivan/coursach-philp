module UI.BookMenu (
  bookMenu
) where
  import Data.Char (isDigit)
  import Models.Book (createBookList, printBook)
  import Modules.File (customReadFile)
  import UI.Types (Store, createStore)
  import UI.Tools (clearScreen, printError, printHeader, printPagination, printNotice)

  _PAGINATE_PER :: Int
  _PAGINATE_PER = 6

  bookMenu :: Int -> IO (Store)
  bookMenu pageNumber = do
    printHeader "Книги"

    contents <- customReadFile "db/book_db.txt"
    let linesOfFile = lines contents
    let bookList = createBookList linesOfFile []

    putStrLn ""
    putStrLn (replicate 100 '-')
    mapM_ printBook (take _PAGINATE_PER (drop ((pageNumber - 1) * _PAGINATE_PER) bookList))
    putStrLn ""

    printNotice "Чтобы выйти в главное меню, напишите: 'Exit'"

    let pages = ceiling (fromIntegral (length bookList) / fromIntegral _PAGINATE_PER)
    printPagination pageNumber pages

    input <- getLine
    if (all isDigit input)
      then do
        let index = read input :: Int
        digitOperations index pages pageNumber
      else do
        stringOperations input pageNumber

  digitOperations :: Int -> Int -> Int -> IO (Store)
  digitOperations index pages pageNumber
    | (index <= pages) = do
      clearScreen
      bookMenu index
    | otherwise = do
      clearScreen
      printError "Выход за пределы пагинации"
      bookMenu pageNumber

  stringOperations :: String -> Int -> IO (Store)
  stringOperations inputValue pageNumber =
    case compare inputValue "Exit" of
      EQ -> do
        return (createStore "StartMenu" "")
      _ -> do
        clearScreen
        printError "Некорректное значение"
        bookMenu pageNumber