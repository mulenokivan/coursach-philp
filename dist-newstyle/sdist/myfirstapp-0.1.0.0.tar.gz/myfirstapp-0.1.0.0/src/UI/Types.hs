module UI.Types (
  Store,
  initStore,
  createStore,
  getCurrentRoute
) where

  data Store = Store {
    currentRoute :: String,
    search :: String
  }

  initStore :: Store
  initStore = Store "MainStore" ""

  -- Constructor
  createStore :: String -> String -> Store
  createStore currentRoute search = Store currentRoute search

  getCurrentRoute :: Store -> String
  getCurrentRoute (Store currentRoute _) = currentRoute