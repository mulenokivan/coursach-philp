module UI.Routes (
  routes,
) where
  import System.IO.Unsafe (unsafePerformIO)

  import UI.Types (Store, getCurrentRoute, createStore)
  import UI.Tools (clearScreen)
  import UI.StartMenu (startMenu)
  import UI.BookMenu (bookMenu)
  import UI.AuthorMenu (authorMenu)

  routes :: Store -> IO ()
  routes store = do
    case (getCurrentRoute store) of
      "StartMenu" -> do
        clearScreen
        newRoute <- startMenu
        routes newRoute
      "BookMenu" -> do
        clearScreen
        newRoute <- bookMenu 1
        routes newRoute
      "AuthorMenu" -> do
        clearScreen
        newRoute <- authorMenu 1 ""
        routes newRoute
      -- "BasketMenu" -> do
      --   clearScreen
      --   putStrLn "BasketMenu"
      --   let newRoute = startMenu
      --   routes "Exit"
      -- "OrderMenu" -> do
      --   clearScreen
      --   putStrLn "OrderMenu"
      --   let newRoute = startMenu
      --   routes "Exit"
      "Exit" -> do
        putStrLn "Выключение"
        return ()
      _ -> do
        routes (createStore "StartMenu" "")
