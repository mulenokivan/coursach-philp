module UI.StartMenu (
  startMenu,
  clearScreen
) where
  import Data.Char (isDigit)
  import System.IO (hFlush, hSetEncoding, stdin, stdout, utf8)
  import System.IO.Unsafe (unsafePerformIO)
  import qualified System.Console.ANSI as ANSI
  import UI.Types (Store, createStore)
  import UI.Tools (clearScreen, printOptions, printError)

  startMenu :: IO (Store)
  startMenu = do
    putStrLn "Главное меню"
    let options = [
          ("[1] Книги", "BookMenu", True),
          ("[2] Авторы", "AuthorMenu", True),
          ("[3] Корзина", "BasketMenu", True),
          ("[4] Заказы", "OrderMenu", True),
          ("[5] Выйти", "Exit", True)
          ]
    printOptions options

    input <- getLine
    if all isDigit input
      then do
        let index = read input :: Int
        let (_, menuName, _) = unsafePerformIO (getOptionByIndex index options "Главное меню")
        return (createStore menuName "")
      else do
        clearScreen
        startMenu

  getOptionByIndex :: Int -> [(String, String, Bool)] -> String -> IO (String, String, Bool)
  getOptionByIndex index options header
    | (index <= length options) = return (options!! (index - 1))
    | otherwise = do
      clearScreen
      ANSI.setSGR [ANSI.SetColor ANSI.Foreground ANSI.Vivid ANSI.Magenta]
      putStrLn header
      putStrLn ""
      ANSI.setSGR [ANSI.Reset]
      printOptions options
      printError "Неверный ввод"
      input <- getLine
      let newIndex = read input :: Int
      getOptionByIndex newIndex options header
