module Modules.Search (
  searchBookByTitle,
  searchBookByGenre,
  searchBookByCost,

  findAuthor,
  searchAuthorByName,
  searchAuthorByPatronymic,
  searchAuthorBySurname,

  findAuthorsBooks,
  findAuthorBook,

  findBasketById,
  findBasketsItemsByBookId,
  findBasketsItemsByBasketId,

  findSubStrIdx
) where
  -- Models
  import Models.Author
  import Models.Book
  import Models.Basket
  import Models.BasketItem
  import Models.Order

  -- Для поиска
  findBook :: String
  findBook = "findBook"

  findAuthor :: String -> [AuthorType] -> [AuthorType]
  findAuthor inputValue authorList = do
    let authorListByName = searchAuthorByName authorList inputValue
    let authorListBySurname = searchAuthorByPatronymic authorList inputValue
    let authorLiseByPatronymic = searchAuthorBySurname authorList inputValue

    case (authorListByName, authorListBySurname, authorLiseByPatronymic) of
      (x, _, _) -> x
      (_, x, _) -> x
      (_, _, x) -> x
      _ -> []

  -- Book
  findBookByAuthor :: String
  findBookByAuthor = "findBookByAuthor"

  searchBookByTitle :: [BookType] -> String -> [BookType]
  searchBookByTitle [] _ = []
  searchBookByTitle (x:xs) inputValue
    | findSubStrIdx (getBookTitle x) inputValue 0 /= Nothing = x : searchBookByTitle xs inputValue
    | otherwise = searchBookByTitle xs inputValue

  searchBookByGenre :: [BookType] -> String -> [BookType]
  searchBookByGenre [] _ = []
  searchBookByGenre (x:xs) inputValue
    | isFullMatch (getBookGenre x) inputValue = x : searchBookByGenre xs inputValue
    | otherwise = searchBookByGenre xs inputValue

  searchBookByCost :: [BookType] -> Float -> [BookType]
  searchBookByCost [] _ = []
  searchBookByCost (x:xs) inputValue
    | isGreater (getBookCost x) inputValue = x : searchBookByCost xs inputValue
    | otherwise = searchBookByCost xs inputValue

  -- Author
  searchAuthorByName :: [AuthorType] -> String -> [AuthorType]
  searchAuthorByName [] _ = []
  searchAuthorByName (x:xs) inputValue
    | findSubStrIdx (getAuthorName x) inputValue 0 /= Nothing = x : searchAuthorByName xs inputValue
    | otherwise = searchAuthorByName xs inputValue

  searchAuthorByPatronymic :: [AuthorType] -> String -> [AuthorType]
  searchAuthorByPatronymic [] _ = []
  searchAuthorByPatronymic (x:xs) inputValue
    | findSubStrIdx (getAuthorPatronymic x) inputValue 0 /= Nothing = x : searchAuthorByPatronymic xs inputValue
    | otherwise = searchAuthorByPatronymic xs inputValue

  searchAuthorBySurname :: [AuthorType] -> String -> [AuthorType]
  searchAuthorBySurname [] _ = []
  searchAuthorBySurname (x:xs) inputValue
    | findSubStrIdx (getAuthorSurname x) inputValue 0 /= Nothing = x : searchAuthorBySurname xs inputValue
    | otherwise = searchAuthorBySurname xs inputValue

  -- Basket
  findBasketById :: [BasketType] -> Integer -> Maybe BasketType
  findBasketById [] _ = Nothing
  findBasketById (x:xs) basketId
    | (getBasketId x == basketId) = Just x
    | otherwise = findBasketById xs basketId

  -- BasketItem
  findBasketItemById :: [BasketItemType] -> Integer -> Maybe BasketItemType
  findBasketItemById [] _ = Nothing
  findBasketItemById (x:xs) basketItemId
    | (getBasketItemId x == basketItemId) = Just x
    | otherwise = findBasketItemById xs basketItemId

  findBasketsItemsByBookId :: [BasketItemType] -> Integer -> [BasketItemType]
  findBasketsItemsByBookId [] _ = []
  findBasketsItemsByBookId (x:xs) bookId
    | (getBasketItemBookId x == bookId) = x : findBasketsItemsByBookId xs bookId
    | otherwise = findBasketsItemsByBookId xs bookId

  findBasketsItemsByBasketId :: [BasketItemType] -> Integer -> [BasketItemType]
  findBasketsItemsByBasketId [] _ = []
  findBasketsItemsByBasketId (x:xs) basketId
    | (getBasketItemBasketId x == basketId) = x : findBasketsItemsByBasketId xs basketId
    | otherwise = findBasketsItemsByBasketId xs basketId

  -- Order
  findOrderById :: [OrderType] -> Integer -> Maybe OrderType
  findOrderById [] _ = Nothing
  findOrderById (x:xs) orderId
    | (getOrderId x == orderId) = Just x
    | otherwise = findOrderById xs orderId

  findOrderByBasketId :: [OrderType] -> Integer -> Maybe OrderType
  findOrderByBasketId [] _ = Nothing
  findOrderByBasketId (x:xs) basketId
    | (getOrderBasketId x == basketId) = Just x
    | otherwise = findOrderByBasketId xs basketId

  -- Для внутреннего поиска
  findAuthorsBooks :: [BookType] -> Integer -> [BookType]
  findAuthorsBooks [] _ = []
  findAuthorsBooks (x:xs) authorId
    | getBookAuthorId x == authorId = x : findAuthorsBooks xs authorId
    | otherwise = findAuthorsBooks xs authorId

  findAuthorBook :: [AuthorType] -> Integer -> Maybe AuthorType
  findAuthorBook [] _ = Nothing
  findAuthorBook (x:xs) authorId
    | (getAuthorId x == authorId) = Just x
    | otherwise = findAuthorBook xs authorId

  findSubStrIdx :: String -> String -> Integer -> Maybe Integer
  findSubStrIdx "" _ _ = Nothing
  findSubStrIdx s target n
    | take (length target) s == target = Just n
    | otherwise = findSubStrIdx (tail s) target (n + 1)

  -- А они вообще нужны?)
  isFullMatch :: String -> String -> Bool
  isFullMatch s1 s2 = s1 == s2

  isGreater :: Float -> Float -> Bool
  isGreater x y = x <= y