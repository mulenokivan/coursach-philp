module Modules.File (
  customReadFile,
  customWriteFile
) where
  -- Libraries
  import System.Directory
  import System.IO

  -- Outer methods
  customReadFile :: String -> IO String
  customReadFile fileName = do
    contents <- readFile fileName
    return contents

  customWriteFile :: String -> String -> String -> IO ()
  customWriteFile name tempName contents = do
    removeFile name
    writeFile tempName contents
    renameFile tempName name