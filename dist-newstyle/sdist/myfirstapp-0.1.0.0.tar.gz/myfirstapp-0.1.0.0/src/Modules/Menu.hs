module Modules.Menu (

) where

  pagination :: String
  pagination = "pagination"