module Models.Book (
  BookType,
  createBookList,
  printBook,
  getBookAuthorId,
  getBookTitle,
  getBookGenre,
  getBookCost,
  getBookCreatedAt
) where
  -- Modules
  import Modules.ReadDB

  -- Types
  data Date = Date {
    year :: String,
    month :: String,
    day :: String
  }

  data BookType = BookType {
    id :: Integer,
    author_id :: Integer,
    title :: String,
    genre :: String,
    cost :: Float,
    created_at :: Date
  }

  instance Show Date where
    show (Date year month day) =
      day ++ "." ++ month ++ "." ++ year

  instance Show BookType where
    show (BookType id author_id title genre cost created_at) =
      "Название      |  " ++ title ++ "\n" ++
      "Жанр          |  " ++ genre ++ "\n" ++
      "Цена          |  " ++ show cost ++ " руб." ++ "\n" ++
      "Год создания  |  " ++ show created_at ++ "\n" ++
      replicate 100 '-'

  -- Operations with records
  createBookList :: [String] -> [BookType] -> [BookType]
  createBookList [] answer = answer
  createBookList (x:xs) answer =
    createBookList xs (record:answer)

    where
      [_, idString, authorIdString, title, genre, costString, createdAtString] = reverseArray (removeQuotesFromArray (splitOnQuotes x [] []))
      authorId = read idString :: Integer
      bookId = read authorIdString :: Integer
      cost = read costString :: Float
      [year, month, day] = wordsWhen (=='-') createdAtString
      created_at = Date year month day
      record = BookType authorId bookId title genre cost created_at

  -- Print
  printBook :: BookType -> IO ()
  printBook author = putStrLn (show author)

  -- Getters
  getBookAuthorId :: BookType -> Integer
  getBookAuthorId (BookType _ author_id _ _ _ _) = author_id

  getBookTitle :: BookType -> String
  getBookTitle (BookType _ _ title _ _ _) = title

  getBookGenre :: BookType -> String
  getBookGenre (BookType _ _ _ genre _ _) = genre

  getBookCost :: BookType -> Float
  getBookCost (BookType _ _ _ _ cost _) = cost

  getBookCreatedAt :: BookType -> Date
  getBookCreatedAt (BookType _ _ _ _ _ created_at) = created_at