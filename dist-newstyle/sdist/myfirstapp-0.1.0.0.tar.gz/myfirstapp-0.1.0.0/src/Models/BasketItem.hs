module Models.BasketItem (
  BasketItemType,
  createLocalBasketItem,
  createLocalBasketItemFromString,
  createBasketItem,
  deleteBasketItem,
  createBasketItemList,
  getBasketItemId,
  getBasketItemBookId,
  getBasketItemBasketId,
  ifBasketItemFileExist
) where
  -- Libraries
  import System.Directory
  import Data.List

  -- Modules
  import Modules.ReadDB
  import Modules.File

  -- Types
  data BasketItemType = BasketItemType {
    id :: Integer,
    book_id :: Integer,
    basket_id :: Integer
  }

  instance Show BasketItemType where
    show (BasketItemType id book_id basket_id) =
      "BasketItem " ++ show id ++ " " ++ show book_id ++ " " ++ show basket_id

  -- Constants
  _DB_BASKET_ITEM_FILE_NAME :: String
  _DB_BASKET_ITEM_FILE_NAME = "db/basket_item_db.txt"

  _DB_TEMP_FILE_NAME :: String
  _DB_TEMP_FILE_NAME = "db/basket_item_db_temp.txt"

  -- Constructors
  createLocalBasketItem :: Integer -> Integer -> Integer -> BasketItemType
  createLocalBasketItem id bookId basketId = BasketItemType id bookId basketId

  createLocalBasketItemFromString :: String -> Bool -> BasketItemType
  createLocalBasketItemFromString basketItemString isPlusOne =
    if isPlusOne then
      BasketItemType (id + 1) bookId basketId
    else
      BasketItemType id bookId basketId

    where
      [_, idString, bookIdString, basketIdString] = wordsWhen (== ' ') basketItemString
      id = read idString :: Integer
      bookId = read bookIdString :: Integer
      basketId = read basketIdString :: Integer

  -- Operations with records
  createBasketItem :: String -> IO ()
  createBasketItem contents = do
    customWriteFile _DB_BASKET_ITEM_FILE_NAME _DB_TEMP_FILE_NAME contents

  deleteBasketItem :: [String] -> BasketItemType -> IO ()
  deleteBasketItem linesOfFile basketItem = do
    let filteredLinesOfFile = filter (/= show basketItem) linesOfFile
    let test = concat $ intersperse "\n" filteredLinesOfFile
    customWriteFile _DB_BASKET_ITEM_FILE_NAME _DB_TEMP_FILE_NAME test

  createBasketItemList :: [String] -> [BasketItemType] -> [BasketItemType]
  createBasketItemList [] answer = answer
  createBasketItemList (x:xs) answer =
    createBasketItemList xs (record:answer)

    where
      [_, idString, bookIdString, basketIdString] = wordsWhen (== ' ') x
      id = read idString :: Integer
      bookId = read bookIdString :: Integer
      basketId = read basketIdString :: Integer
      record = BasketItemType id bookId basketId

  -- Print
  printBasketItem :: BasketItemType -> IO ()
  printBasketItem basketItem = putStrLn (show basketItem)

  -- Getters
  getBasketItemId :: BasketItemType -> Integer
  getBasketItemId (BasketItemType id _ _) = id

  getBasketItemBookId :: BasketItemType -> Integer
  getBasketItemBookId (BasketItemType _ bookId _) = bookId

  getBasketItemBasketId :: BasketItemType -> Integer
  getBasketItemBasketId (BasketItemType _ _ basketId) = basketId

  -- Conditions
  ifBasketItemFileExist :: IO ()
  ifBasketItemFileExist = do
    exists <- doesFileExist _DB_BASKET_ITEM_FILE_NAME
    if exists then
      return ()
    else
      writeFile _DB_BASKET_ITEM_FILE_NAME ""