module Models.Author (
  AuthorType,
  createAuthorList,
  printAuthor,
  getNameAtIndex,
  getAuthorId,
  getAuthorName,
  getAuthorPatronymic,
  getAuthorSurname
) where
  -- Modules
  import Modules.ReadDB

  -- Types
  data AuthorType = AuthorType {
    id :: Integer,
    name :: String,
    patronymic :: String,
    surname :: String
  }

  instance Show AuthorType where
    show (AuthorType id name surname patronymic) =
      "Имя      | " ++ name ++ "\n" ++
      "Фамилия  | " ++ surname ++ "\n" ++
      "Отчество | " ++ patronymic ++ "\n" ++
      replicate 100 '-'

  -- Operations with records
  createAuthorList :: [String] -> [AuthorType] -> [AuthorType]
  createAuthorList [] answer = answer
  createAuthorList (x:xs) answer =
    createAuthorList xs (record:answer)
    where
      [_, idString, name, surname, patronymic] = reverseArray (removeQuotesFromArray (splitOnQuotes x [] []))
      authorId = read idString :: Integer
      record = AuthorType authorId name surname patronymic

  -- Print
  printAuthor :: AuthorType -> IO ()
  printAuthor author = putStrLn (show author)

  -- Getters
  getNameAtIndex :: [AuthorType] -> Int -> String
  getNameAtIndex authorList i = getAuthorName (authorList !! i)

  getAuthorId :: AuthorType -> Integer
  getAuthorId (AuthorType id _ _ _) = id

  getAuthorName :: AuthorType -> String
  getAuthorName (AuthorType _ name _ _) = name

  getAuthorPatronymic :: AuthorType -> String
  getAuthorPatronymic (AuthorType _ _ patronymic _) = patronymic

  getAuthorSurname :: AuthorType -> String
  getAuthorSurname (AuthorType _ _ _ surname) = surname