module Models.Order (
  OrderType,
  createLocalOrder,
  createLocalOrderFromString,
  createOrder,
  createOrderList,
  printOrder,
  getOrderId,
  getOrderBasketId,
  getOrderPrice,
  ifOrderFileExist,
) where
  -- Libraries
  import System.Directory
  import Data.List

  -- Modules
  import Modules.ReadDB
  import Modules.File

  -- Types
  data OrderType = OrderType {
    id :: Integer,
    basket_id :: Integer,
    price :: Float
  }

  instance Show OrderType where
    show (OrderType id basket_id price) =
      "Order " ++ show id ++ " " ++ show basket_id ++ " " ++ show price

  -- Constants
  _DB_ORDER_FILE_NAME :: String
  _DB_ORDER_FILE_NAME = "db/order_db.txt"

  _DB_TEMP_FILE_NAME :: String
  _DB_TEMP_FILE_NAME = "db/order_db_temp.txt"

  -- Constructors
  createLocalOrder :: Integer -> Integer -> Float -> OrderType
  createLocalOrder id basketId price = OrderType id basketId price

  createLocalOrderFromString :: String -> Bool -> OrderType
  createLocalOrderFromString orderString isPlusOne =
    if isPlusOne then
      OrderType (id + 1) basketId price
    else
      OrderType id basketId price

    where
      [_, idString, basketIdString, priceString] = wordsWhen (== ' ') orderString
      id = read idString :: Integer
      basketId = read basketIdString :: Integer
      price = read priceString :: Float

  -- Operations with records
  createOrder :: String -> IO ()
  createOrder contents = do
    customWriteFile _DB_ORDER_FILE_NAME _DB_TEMP_FILE_NAME contents

  createOrderList :: [String] -> [OrderType] -> [OrderType]
  createOrderList [] answer = answer
  createOrderList (x:xs) answer =
    createOrderList xs (record:answer)

    where
      [_, idString, basketIdString, priceString] = wordsWhen (== ' ') x
      id = read idString :: Integer
      basketId = read basketIdString :: Integer
      price = read priceString :: Float
      record = OrderType id basketId price

  -- Print
  printOrder :: OrderType -> IO ()
  printOrder order = putStrLn (show order)

  -- Getters
  getOrderId :: OrderType -> Integer
  getOrderId (OrderType id _ _) = id

  getOrderBasketId :: OrderType -> Integer
  getOrderBasketId (OrderType _ basketId _) = basketId

  getOrderPrice :: OrderType -> Float
  getOrderPrice (OrderType _ _ price) = price

  -- Conditions
  ifOrderFileExist :: IO ()
  ifOrderFileExist = do
    exists <- doesFileExist _DB_ORDER_FILE_NAME
    if exists then
      return ()
    else
      writeFile _DB_ORDER_FILE_NAME ""