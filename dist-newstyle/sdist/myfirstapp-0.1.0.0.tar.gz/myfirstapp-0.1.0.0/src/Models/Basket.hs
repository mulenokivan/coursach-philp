module Models.Basket (
  BasketType,
  createLocalBasket,
  createLocalBasketFromString,
  createBasket,
  deleteBasket,
  createBasketList,
  printBasket,
  ifBasketFileExist,
  getBasketId
) where
  -- Libraries
  import System.Directory
  import Data.List

  -- Modules
  import Modules.ReadDB
  import Modules.File

  -- Types
  data BasketType = BasketType {
    id :: Integer
  }

  instance Show BasketType where
    show (BasketType id) =
      "Basket" ++ show id

  -- Constants
  _DB_BASKET_FILE_NAME :: String
  _DB_BASKET_FILE_NAME = "db/basket_db.txt"

  _DB_TEMP_FILE_NAME :: String
  _DB_TEMP_FILE_NAME = "db/basket_db_temp.txt"

  -- Constructors
  createLocalBasket :: Integer -> BasketType
  createLocalBasket id = BasketType id

  createLocalBasketFromString :: String -> Bool -> BasketType
  createLocalBasketFromString basketString isPlusOne =
    if isPlusOne then
      BasketType (id + 1)
    else
      BasketType id

    where
      [_, idString] = wordsWhen (== ' ') basketString
      id = read idString :: Integer

  -- Operations with records
  createBasket :: String -> IO ()
  createBasket contents = do
    customWriteFile _DB_BASKET_FILE_NAME _DB_TEMP_FILE_NAME contents

  deleteBasket :: [String] -> BasketType -> IO ()
  deleteBasket linesOfFile basket = do
    let filteredLinesOfFile = filter (/= show basket) linesOfFile
    let test = concat $ intersperse "\n" filteredLinesOfFile
    customWriteFile _DB_BASKET_FILE_NAME _DB_TEMP_FILE_NAME test

  createBasketList :: [String] -> [BasketType] -> [BasketType]
  createBasketList [] answer = answer
  createBasketList (x:xs) answer =
    createBasketList xs (record:answer)

    where
      [_, idString] = wordsWhen (== ' ') x
      id = read idString :: Integer
      record = BasketType id

  -- Print
  printBasket :: BasketType -> IO ()
  printBasket basket = putStrLn (show basket)

  -- Getters
  getBasketId :: BasketType -> Integer
  getBasketId (BasketType id) = id

  -- Conditions
  ifBasketFileExist :: IO ()
  ifBasketFileExist = do
    exists <- doesFileExist _DB_BASKET_FILE_NAME
    if exists then
      return ()
    else
      writeFile _DB_BASKET_FILE_NAME ""